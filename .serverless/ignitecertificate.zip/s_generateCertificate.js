
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'mateuspersi',
  applicationName: 'ignitecertificate',
  appUid: '35PHWp2t3dVpZGdCY1',
  orgUid: '2770ca93-9965-4e4a-97bf-0d1274b4017e',
  deploymentUid: '2a5eba02-e2fc-412b-a7f8-f6c40c0bfe08',
  serviceName: 'ignitecertificate',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'ignitecertificate-dev-generateCertificate', timeout: 6 };

try {
  const userHandler = require('./src/functions/generateCertificate.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handle, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}